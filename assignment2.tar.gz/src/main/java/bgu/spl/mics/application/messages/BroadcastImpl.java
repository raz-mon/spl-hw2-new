package bgu.spl.mics.application.messages;



// raz built.

import bgu.spl.mics.Broadcast;

public class BroadcastImpl implements Broadcast {


}

