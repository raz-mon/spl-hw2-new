package bgu.spl.mics;



public class AttackEvent {
}
